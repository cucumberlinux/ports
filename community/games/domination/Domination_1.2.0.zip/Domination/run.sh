#!/bin/sh
cd "`dirname "$0"`"
java -jar Domination.jar "$@"
